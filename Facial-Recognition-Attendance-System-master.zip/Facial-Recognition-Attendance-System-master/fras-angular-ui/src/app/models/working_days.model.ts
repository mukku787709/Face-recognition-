export interface WorkingDaysData {
    date: string
    present_students:number
    id: number
}