#!/usr/bin/env bash

#cd ~/fras/code/raspberry-pi-client
~/doorbell_env/bin/python run_camera_client.py